#pragma once
#include "USB_MessageQueue.h"
//#include "F:\HzcVision\CCTAPI_USB\CCTAPI\USB_DataProcess.h"
//extern int g_width_L;

//#define RGB565
//#define	Array2_Index(i,j)	  i*Video_Width+j
#ifdef RGB565
#define g_width_L                       g_width*2
#else

#endif
#define Sig_L							4
//#define ReadDataBytes                   163840//(Video_Width_L+Sig_L)*Video_Height
typedef
VOID
(WINAPI * LPMV_CALLBACK2)(LPVOID lpParam, LPVOID lpUser);				
enum UsbDataProcessType
{
	UsbNormal_Proc,UsbXmirror_Proc,UsbYmirror_Proc,UsbXYmirror_Proc,UsbRGExchange_Proc
};
//void _stdcall RawCallBack(LPVOID lpParam,LPVOID lpUser);
enum UsbRgbChangeType//R G B��Ԫ�ػ�������
{
	UsbNormal_Change,UsbRG_Change,UsbRB_Change,UsbGB_Change
};

struct UsbtagRGB
{
	byte UsbB;
	byte UsbG;
	byte UsbR;
	UsbtagRGB()
	{
		memset(this,0,sizeof(*this));
	}
};

class CUSBDataProcess
{
public:
	CUSBDataProcess(void);
	~CUSBDataProcess(void);

public:
	int Open(int height,int width,LPMV_CALLBACK2 CallBackFunc);
	int Close();
	int	Input(VOID * pData,int dwSizes);
	int GetFrameCount(int& fCount);
	int SetProcType(UsbDataProcessType type);
	int SetChangeType(UsbRgbChangeType type);
	

private:
	void ThreadProcessFunction();
	static unsigned int __stdcall ThreadProcess(void *handle);

private:
	//int ByteToRGB(byte pIn[Video_Height][Video_Width_L] ,tagRGB pOut[Video_Height][Video_Width]);
	int	ProcessData();
	int ByteToRGB(byte *pIn ,UsbtagRGB* pOut);
	int PutMessage(UD_MESSAGE *msg);
	void CloseMsgQueue();
	void DoXmirrorProc();//X�᾵����
	void DoYmirrorProc();//Y�᾵����
	void RgbChangeProc(UsbtagRGB& DestRgb,const UsbtagRGB& OrgRgb);//RGBԪ�ػ�������
	void CreateBmpFile();

private:
	HANDLE m_hThread;
	UD_MESSAGE *m_pPutMsg, *m_pGetMsg;
	CUSBMessageQueue m_MsgQueue;
	C_MutexUSB	m_Mutex;
	BOOL m_bEnd;
	int m_lFrameCount;//ͼ��֡����
	UsbDataProcessType m_ProcType;
	UsbRgbChangeType m_ChangeType;
	int OutPutWrapper(LPMV_CALLBACK2 CallBackFunc,LPVOID lpUser);
	LPMV_CALLBACK2 h_callback;
private:
	BITMAPINFO	m_BitmapInfo;
	HDC			m_hDC;
	byte*       m_In;
	UsbtagRGB*     m_Out;
	int g_height,g_width,g_width_L;
	BOOL        m_bCreateBmp;
};
