#pragma once
#include "USB_DataProcess.h"
#include "CyAPI.h"

class CUSBDataCapture
{
public:
	CUSBDataCapture(CCyUSBDevice *usb);
	virtual ~CUSBDataCapture(void);

public:
	int Open(CUSBDataProcess *pProcess,int height,int width);//
	int Close();
	int Input(const LPVOID lpData,const DWORD dwSize);
	int startThread();
	int ReadData(char* pbuff,LONG &lBytes);
	long m_lBytePerSecond;
private:
	CUSBDataProcess *m_pDataProcess;
	int			m_iCount;		//���ݼ�����
	int			m_iRowIndex;	//������
	bool        m_bFindDbFive;	//����Ƿ��ҵ�55
	byte*		m_pInData;		//�������ݻ���
	byte*		m_pOutData;		//������ݻ���
	char* m_pReadBuff;
	long UsbReadDataBytes;
	long lRet;
	static unsigned int __stdcall ThreadProcess( void* handle );
	int ThreadProcessFunction();
	HANDLE m_hThread;
	volatile BOOL m_bCapture;
	int g_width_L;
	int g_width;
	int g_height;
	CCyUSBDevice *m_Usb;
};

