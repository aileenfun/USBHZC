#pragma once
#include <afxmt.h>

class C_MutexUSB
{
public:
	inline C_MutexUSB::C_MutexUSB()
	{
	};
	inline C_MutexUSB::~C_MutexUSB()
	{
	};
	inline void C_MutexUSB::Lock()
	{
		m_Sem.Lock();
	};
	inline void C_MutexUSB ::UnLock()
	{
		m_Sem.Unlock();
	};
private:
		CSemaphore m_Sem;
};

class CUSBGuard
{
public:
	
inline CUSBGuard::CUSBGuard(C_MutexUSB &mutex):m_Mutex(mutex)
{
	m_Mutex.Lock();
};
inline CUSBGuard::~CUSBGuard()
{
	m_Mutex.UnLock();
};
private:
	 C_MutexUSB &m_Mutex;
};
